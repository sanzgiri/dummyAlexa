module.exports = {
  appid: "amzn1.echo-sdk-ams.app.df7e3f30-537a-42f1-8213-4a302b96c39e",
  remoteAPI: "http://jservice.io/api/random",
  homepage: "alexa<say-as interpret-as\"characters\">io</say-as> dot com forward slash dummy",
  homepageurl: "http://alexaio.com/dummy",
  delayBeforeAnswer: 5
};
